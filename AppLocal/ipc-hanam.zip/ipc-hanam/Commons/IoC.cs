﻿using AFS.HMILibrary.Wpf;
using AFSClient;
using ipc_hanam.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ipc_hanam
{
    public class IoC
    {
        public static IoC Instance { get; private set; } = new IoC();

        public string AppPath { get; private set; } = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        public AppSettings AppSettings { get; set; }

        public StationModel Station { get; set; }

        public string TagPrefix { get; set; } = "0/Connectivity/summary/tags";

        public IServerConnector ServerConnector { get; set; }

        private IoC()
        {
            ServerConnector = ServerConnectorProvider.GetConnector(0);

            Station = new StationModel();
            Station.ModuleWatt = 450;
            Station.RatedACCapacitor = 4000;
            Station.RatedDCCapacity = 5887.9;
            Station.TotalModules = 10862;
            Station.TotalInverters = 40;

            for (int i = 1; i <= 7; i++)
            {
                LoggerModel logger = new LoggerModel()
                {
                    DisplayName = $"Logger PVS {i}",
                    Index = i,
                    DeviceId = $"{i}",
                    Model = "Smart Logger Huawei",
                    TagPrefix = $"0/Connectivity/pvs{i}/logger"
                };
                Station.Loggers.Add(logger);

                if (i == 3 || i == 7)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        InverterModel inverter = new InverterModel()
                        {
                            DisplayName = $"Inverter {j}",
                            Model = "SUN2000-10pKTL-M1x",
                            Status = "",
                            DeviceId = "",
                            Index = j,
                            TagPrefix = $"0/Connectivity/pvs{i}/invt{j}",
                            HistoryPath = $"Historians/pvs{i}_invt{j}",
                            AlarmPath = $"Alarm loggers/pvs{i}_invt{j}",
                        };
                        logger.Inverters.Add(inverter);
                    }
                }
                else
                {
                    for (int j = 1; j <= 6; j++)
                    {
                        InverterModel inverter = new InverterModel()
                        {
                            DisplayName = $"Inverter {j}",
                            Model = "SUN2000-10pKTL-M1x",
                            Status = "",
                            DeviceId = "",
                            Index = j,
                            TagPrefix = $"0/Connectivity/pvs{i}/invt{j}",
                            HistoryPath = $"Historians/pvs{i}_invt{j}",
                            AlarmPath = $"Alarm loggers/pvs{i}_invt{j}",
                        };
                        logger.Inverters.Add(inverter);
                    }
                }

                logger.EnergyPowerMeter = new EnergyPowerMeterModel()
                {
                    Model = "PM5310",
                    DisplayName = "Energy Power Meter",
                    DeviceId = $"PVS{i}/PM5310",
                    TagPrefix = $"0/Connectivity/pvs{i}-pm/Device",

                };

                logger.ElectricalQualityMeter = new ElectricalQualityMeterModel()
                {
                    Model = "KN612",
                    DisplayName = "Electrical Quality Meter",
                    DeviceId = $"PVS{i}/KN612",
                    TagPrefix = $"0/Connectivity/pvs{i}-kn612/Device"
                };

                logger.ZeroExportPowerMeter = new ZeroExportPowerMeterModel()
                {
                    Model = "PM5310",
                    DisplayName = "Zero Export Power Meter",
                    DeviceId = $"PVS{i}/ZE-PM5310",
                    TagPrefix = $"0/Connectivity/pvs{i}/zero-export"
                };

                logger.Start();
            }
             
            this.LoadTags(true);
            
            ServerConnector.Start();
        }

        public TagNode daily_energy_yields { get; set; }
        public TagNode monthly_energy_yields { get; set; }
        public TagNode yearly_energy_yields { get; set; }
        public TagNode total_energy_yields { get; set; }
        public TagNode co2_reduction { get; set; }
        public TagNode coal_saved { get; set; }
        public TagNode tree_planted { get; set; }
        public TagNode total_input_power { get; set; }
        public TagNode total_output_power { get; set; }
        public TagNode radiation { get; set; }
        public TagNode panel_temperature { get; set; }
        public TagNode wind_speed { get; set; }
        public TagNode total_active_power_pm { get; set; }
        public TagNode total_energy_pm { get; set; }
        public TagNode total_active_power_ze { get; set; }
        public TagNode total_energy_ze { get; set; }
    }
}
